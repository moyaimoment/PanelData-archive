How to use:
Call this program with the path to directory as the first argument
that contains the files that should be packed into the PNEL file.
If no argument is given a File Chooser will let you choose
a directory

Format of the needed files for every puzzle:
<order number>_titleNames.bin
<order number>_image.bin
<order number>_settings.bin
<order number>_model.bin
where <order number> is a number between 7-99

More info: https://www.3dbrew.org/wiki/PNEL
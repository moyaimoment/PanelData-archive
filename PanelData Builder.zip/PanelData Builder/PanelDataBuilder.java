/*
 * How to use:
 * Call this program with the path to directory as the first argument
 * that contains the files that should be packed into the PNEL file.
 * If no argument is given a File Chooser will let you choose
 * a directory
 * 
 * Format of the needed files for every puzzle:
 * <order number>_titleNames.bin
 * <order number>_image.bin
 * <order number>_settings.bin
 * <order number>_model.bin
 * where <order number> is a number between 7-99
 * 
 * More info: https://www.3dbrew.org/wiki/PNEL
 */

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.zip.CRC32;

import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class PanelDataBuilder {
	
	static String workPath = System.getProperty("user.home") + "/ExtracetdPanelData/";
	static String panelFileName = "PanelData.dat";
	
	public static void main(String[] args) {
		
		if(args.length < 1) {
			JFrame window = new JFrame("PanelData Builder");
			window.setLocationRelativeTo(null);
			window.setVisible(true);
			JFileChooser fc = new JFileChooser();
			fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			int returnVal = fc.showOpenDialog(null);
			window.dispose();
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				workPath = fc.getSelectedFile().toPath().toString() + "/";
			} else {
				return;
			}
		} else {
			Path p = Paths.get(args[0]);
			workPath = p.getParent().toString();
		}
		
		try {
			writePanelFile();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void writePanelFile() throws Exception {
		DirectoryStream<Path> dirStream = Files.newDirectoryStream(Paths.get(workPath));
		RandomAccessFile raf = new RandomAccessFile(workPath + panelFileName, "rw");
		raf.setLength(0);//delete all contents if the file already exists
		HashMap<Integer,Path> titleFiles = new HashMap<Integer,Path>(100);
		HashMap<Integer,Path> imageFiles = new HashMap<Integer,Path>(100);
		HashMap<Integer,Path> settingsFiles = new HashMap<Integer,Path>(100);
		HashMap<Integer,Path> modelFiles = new HashMap<Integer,Path>(100);
		
		for(Path file : dirStream) {
			String[] orderAndPart = file.getFileName().toString().split("_");
			int order = 0;
			try {
				order = Integer.parseInt(orderAndPart[0]);
			} catch (NumberFormatException nfe) {
				continue;
			}
			if(orderAndPart[1].startsWith("titleNames")) {
				titleFiles.put(order, file);
			} else if (orderAndPart[1].startsWith("image")) {
				imageFiles.put(order, file);
			} else if (orderAndPart[1].startsWith("settings")) {
				settingsFiles.put(order, file);
			} else if (orderAndPart[1].startsWith("model")) {
				modelFiles.put(order, file);
			}
		}
		
		TreeMap<Integer,Path> titleFilesSorted = new TreeMap<Integer,Path>(titleFiles);
		byte[] writeBuffer = null;
		int puzzleCount = titleFilesSorted.size();
		
		CRC32 crc32Calc = new CRC32();
		//write Panel Header
		ByteBuffer header = ByteBuffer.allocate(0x14).order(ByteOrder.LITTLE_ENDIAN);
		header.put("PNEL0800".getBytes());
		header.putInt(puzzleCount);
		header.putInt(1);//unknown; maybe a file version field
		header.putInt(0);//CRC-32 over header
		crc32Calc.reset();
		crc32Calc.update(header.array());
		header.putInt(0x10, (int) crc32Calc.getValue());
		raf.write(header.array());
		
		long currentPuzzleHeaderPos = raf.getFilePointer();
		raf.seek(raf.getFilePointer() + (puzzleCount * 0xC30));
		
		long currentPuzzleImagePos = raf.getFilePointer();
		
		for(int order : titleFilesSorted.keySet()) {
			raf.seek(currentPuzzleImagePos);
			
			//write image
			writeBuffer = Files.readAllBytes(imageFiles.get(order));
			crc32Calc.reset();
			crc32Calc.update(writeBuffer);
			int crc32Image = (int) crc32Calc.getValue();
			long imagePos = raf.getFilePointer();
			int imageSize = writeBuffer.length;
			raf.write(writeBuffer);
			writePaddingAlignment(raf, writeBuffer.length);
			
			//write settings
			writeBuffer = Files.readAllBytes(settingsFiles.get(order));
			crc32Calc.reset();
			crc32Calc.update(writeBuffer);
			int crc32Settings = (int) crc32Calc.getValue();
			long settingsPos = raf.getFilePointer();
			int settingsSize = writeBuffer.length;
			raf.write(writeBuffer);
			writePaddingAlignment(raf, writeBuffer.length);
			
			//write model
			writeBuffer = Files.readAllBytes(modelFiles.get(order));
			crc32Calc.reset();
			crc32Calc.update(writeBuffer);
			int crc32Model = (int) crc32Calc.getValue();
			long modelPos = raf.getFilePointer();
			int modelSize = writeBuffer.length;
			raf.write(writeBuffer);
			writePaddingAlignment(raf, writeBuffer.length);
			
			currentPuzzleImagePos = raf.getFilePointer();
			raf.seek(currentPuzzleHeaderPos);
			
			//write Header of Puzzle entry
			ByteBuffer puzzleHeader = ByteBuffer.allocate(0xC30).order(ByteOrder.LITTLE_ENDIAN);
			puzzleHeader.putInt(order);
			puzzleHeader.putInt(0);//CRC32 over puzzle Header
			puzzleHeader.putInt((int) imagePos);
			puzzleHeader.putInt((int) settingsPos);
			puzzleHeader.putInt((int) modelPos);
			puzzleHeader.putInt(imageSize);
			puzzleHeader.putInt(settingsSize);
			puzzleHeader.putInt(modelSize);
			puzzleHeader.putInt(crc32Image);
			puzzleHeader.putInt(crc32Settings);
			puzzleHeader.putInt(crc32Model);
			puzzleHeader.put(Files.readAllBytes(titleFilesSorted.get(order)));
			crc32Calc.reset();
			crc32Calc.update(puzzleHeader.array());
			puzzleHeader.putInt(4, (int) crc32Calc.getValue());
			raf.write(puzzleHeader.array());
			
			currentPuzzleHeaderPos = raf.getFilePointer();
		}
		raf.close();
		System.out.println("PNEL file successfully build and written to: " + workPath + panelFileName);
	}
	
	public static void writePaddingAlignment(RandomAccessFile raf, int size) {
		int numPaddingBytes = 4 - (size % 4);
		if (numPaddingBytes == 4)
			numPaddingBytes = 0;
		try {
			for (int i = 0; i < numPaddingBytes; i++)
				raf.write(0);
		} catch (IOException e) {
			System.out.print("Error while writing padding bytes");
			e.printStackTrace();
		}
	}
}

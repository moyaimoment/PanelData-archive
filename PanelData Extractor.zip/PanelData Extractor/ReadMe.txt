How to use:
Call this program with the path to file as the first argument
that should be extracted into its components.
If no argument is given a File Chooser will let you choose
a file.

If the file is a PNEL file it will create a folder with
the name "ExtractedPanelData" in the same folder as the
selected file. All content will be extracted into this
folder.

More info: https://www.3dbrew.org/wiki/PNEL


For a PNEL file you can extract your own from your Nintendo 3DS
If your using FBI select Ext Save Data->StreetPass Mii Plaza->Browse SpotPass Data
Then copy the biggest file to your SD Card.
On your computer delete the first 52 (0x34) bytes of file until the word PNEL.
The file should now be useable with this tool.
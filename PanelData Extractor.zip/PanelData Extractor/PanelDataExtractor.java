/*
 * How to use:
 * Call this program with the path to file as the first argument
 * that should be extracted into its components.
 * If no argument is given a File Chooser will let you choose
 * a file.
 * 
 * If the file is a PNEL file it will create a folder with
 * the name "ExtractedPanelData" in the same folder as the
 * selected file. All content will be extracted into this
 * folder.
 * 
 * More info: https://www.3dbrew.org/wiki/PNEL
 */

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.zip.CRC32;

import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class PanelDataExtractor {
	
	static ByteBuffer fileData8Bytes = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
	static String workPath = System.getProperty("user.home");
	static String extractDir = "ExtractedPanelData/"; //relative to workPath
	static String fileName = "";

	public static void main(String[] args) {
		
		if(args.length < 1) {
			JFrame window = new JFrame("PanelData Extractor");
			window.setLocationRelativeTo(null);
			window.setVisible(true);
			JFileChooser fc = new JFileChooser();
			int returnVal = fc.showOpenDialog(window);
			window.dispose();
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				workPath = fc.getSelectedFile().toPath().getParent().toString().replace("\\", "/") + "/";
				fileName = fc.getSelectedFile().toPath().getFileName().toString();
			} else {
				return;
			}
		} else {
			Path p = Paths.get(args[0]);
			workPath = p.getParent().toString().replace("\\", "/") + "/";
			fileName = p.getFileName().toString();
		}
	
		RandomAccessFile raf = null;
		
		try {
			raf = new RandomAccessFile(workPath + fileName,"r");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		if(raf == null) {
			return;
		}
		
		
		FileChannel fc = raf.getChannel();
		String magicWord = readString(fc, 8);
		if (!magicWord.equals("PNEL0800")) {
			System.out.println("The given file is not a PanelData file. No magic word PNEL0800 at beginning of file.");
			try {
				raf.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return;
		}
		
		if(!Files.exists(Paths.get(workPath + extractDir))) {
			try {
				Files.createDirectory(Paths.get(workPath + extractDir));
			} catch (IOException e) {
				e.printStackTrace();
				return;
			}
		}
		
		CRC32 crc32Calc = new CRC32();
		
		int numberOfPuzzles = readInt(fc);
		readInt(fc);// unknown always 0x000001
		readInt(fc);// CRC 32 of header with this field beeing 0
		for(int i = 0; i < numberOfPuzzles; i++) {
			byte[] puzzleEntry = null;
			try {
				puzzleEntry = readBytes(fc, (int) fc.position(), 0xC30);
				puzzleEntry[4] = 0;//set the CRC-32 value to 0 for CRC-32 calculation
				puzzleEntry[5] = 0;
				puzzleEntry[6] = 0;
				puzzleEntry[7] = 0;
			} catch (IOException e) {e.printStackTrace();}
			int puzzleOrder = readInt(fc);
			int crc32PuzzleEntry = readInt(fc); // maybe some crc or hash
			int beginImage = readInt(fc);//absolut offset
			int beginSettings = readInt(fc);//absolut offset
			int beginModel = readInt(fc);//absolut offset
			int lengthImage = readInt(fc);
			int lengthSettings = readInt(fc);
			int lengthModel = readInt(fc);
			int crc32Image = readInt(fc);
			int crc32Settings = readInt(fc);
			int crc32Model = readInt(fc);
			
			
			crc32Calc.reset();
			crc32Calc.update(puzzleEntry);
			if((int) crc32Calc.getValue() != crc32PuzzleEntry) {//cast to int because of sign
				System.out.println("Puzzle Entry data of puzzle with order number " + puzzleOrder + " seems to be corrupted\n"
						+ "CRC32 doesn't match");
			}
			
			//extract the names of the titles and puzzle piece format
			byte[] titleNames_arr = readBytes(fc, 0xC04);
			writeArrayToFile(titleNames_arr, workPath + extractDir + puzzleOrder + "_titleNames.bin");
			
			//extract picture
			byte[] image_arr = readBytes(fc, beginImage, lengthImage);
			crc32Calc.reset();
			crc32Calc.update(image_arr);
			if((int) crc32Calc.getValue() != crc32Image) {
				System.out.println("Image data of puzzle with order number " + puzzleOrder + " seems to be corrupted\n"
						+ "CRC32 doesn't match");
			}
			writeArrayToFile(image_arr, workPath + extractDir + puzzleOrder + "_image.bin");
			
			//extract settings
			byte[] settings_arr = readBytes(fc, beginSettings, lengthSettings);
			crc32Calc.reset();
			crc32Calc.update(settings_arr);
			if((int) crc32Calc.getValue() != crc32Settings) {
				System.out.println("Settings data of puzzle with order number " + puzzleOrder + " seems to be corrupted\n"
						+ "CRC32 doesn't match");
			}
			writeArrayToFile(settings_arr, workPath + extractDir + puzzleOrder + "_settings.bin");
			
			//extract model
			byte[] model_arr = readBytes(fc, beginModel, lengthModel);
			crc32Calc.reset();
			crc32Calc.update(model_arr);
			if((int) crc32Calc.getValue() != crc32Model) {
				System.out.println("Model data of puzzle with order number " + puzzleOrder + " seems to be corrupted\n"
						+ "CRC32 doesn't match");
			}
			writeArrayToFile(model_arr, workPath + extractDir + puzzleOrder + "_model.bin");
		}
		
		try {
			raf.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Successfully exported all files to: " + workPath + extractDir);
	}
	
	static String readString(FileChannel fc, int length) {
		StringBuilder sb = new StringBuilder(length);
		ByteBuffer str1 = ByteBuffer.allocate(length);
		try {
			fc.read(str1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		str1.rewind();
		while(str1.hasRemaining()) {
			sb.append((char) str1.get());
		}
		
		return sb.toString();
	}
	
	static long readLong(FileChannel fc) {
		fileData8Bytes.clear();
		fileData8Bytes.limit(8);
		try {
			fc.read(fileData8Bytes);
		} catch (IOException e) {
			e.printStackTrace();
		}
		fileData8Bytes.rewind();
		return fileData8Bytes.getLong();
	}
	
	static int readInt(FileChannel fc) {
		fileData8Bytes.clear();
		fileData8Bytes.limit(4);
		try {
			fc.read(fileData8Bytes);
		} catch (IOException e) {
			e.printStackTrace();
		}
		fileData8Bytes.rewind();
		return fileData8Bytes.getInt();
	}
	
	static byte[] readBytes(FileChannel fc, int length) {
		ByteBuffer bb = ByteBuffer.allocate(length);
		try {
			fc.read(bb);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return bb.array();
	}
	
	static byte[] readBytes(FileChannel fc, int position, int length) {
		ByteBuffer bb = ByteBuffer.allocate(length);
		try {
			fc.read(bb, position);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return bb.array();
	}
	
	static void writeArrayToFile(byte[] arr, String fileName) {
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(fileName);
			fos.write(arr);
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
